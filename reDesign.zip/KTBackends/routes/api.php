<?php

use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\EstimationController;
use App\Http\Controllers\Api\InvoiceController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\PurchaseController;
use App\Http\Controllers\Api\ReportController;
use App\Http\Controllers\Api\StockController;
use App\Http\Controllers\Api\SupplierController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Kathir Traders API Routes
|--------------------------------------------------------------------------
| All routes are prefixed with /api automatically by Laravel 11.
*/

// Dashboard summary (aggregate KPIs for the owner dashboard)
Route::get('dashboard/summary', [DashboardController::class, 'summary']);

// Reports (date-range aggregates for the owner)
Route::prefix('reports')->group(function () {
    Route::get('/sales',           [ReportController::class, 'sales']);
    Route::get('/purchases',       [ReportController::class, 'purchases']);
    Route::get('/stock',           [ReportController::class, 'stock']);
    Route::get('/gst',             [ReportController::class, 'gst']);
    Route::get('/customer-ledger', [ReportController::class, 'customerLedger']);
    Route::get('/supplier-ledger', [ReportController::class, 'supplierLedger']);
});

// Customers
Route::apiResource('customers', CustomerController::class);

// Suppliers
Route::apiResource('suppliers', SupplierController::class);

// Products (with search via ?q=term)
Route::apiResource('products', ProductController::class);

// Stock Management
Route::prefix('stock')->group(function () {
    Route::get('/',                    [StockController::class, 'index']);
    Route::get('/low',                 [StockController::class, 'lowStock']);
    Route::get('/check',               [StockController::class, 'checkAvailability']);
    Route::get('/product/{productId}', [StockController::class, 'byProduct']);
    Route::post('/adjust',             [StockController::class, 'adjust']);
});

// Sales Invoices
Route::get('invoices/by-number/{number}', [InvoiceController::class, 'showByNumber']);
Route::apiResource('invoices', InvoiceController::class)->only(['index', 'show', 'store']);
Route::put('invoices/{invoice}',    [InvoiceController::class, 'update']);
Route::post('invoices/{invoice}/confirm', [InvoiceController::class, 'confirm']);
Route::post('invoices/{invoice}/cancel',  [InvoiceController::class, 'cancel']);

// Purchase Orders
Route::apiResource('purchases', PurchaseController::class)->only(['index', 'show', 'store']);
Route::post('purchases/{purchase}/receive', [PurchaseController::class, 'markReceived']);
Route::post('purchases/{purchase}/cancel',  [PurchaseController::class, 'cancel']);

// Retail Orders (POS)
Route::apiResource('orders', OrderController::class)->only(['index', 'show', 'store']);

// Estimations
Route::get('estimations/by-number/{number}', [EstimationController::class, 'showByNumber']);
Route::apiResource('estimations', EstimationController::class)
    ->except(['update'])
    ->names('estimations');
Route::patch('estimations/{estimation}', [EstimationController::class, 'update']);
