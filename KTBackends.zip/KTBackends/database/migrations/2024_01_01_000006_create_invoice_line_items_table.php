<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoice_line_items', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('sales_invoice_id')->constrained('sales_invoices')->cascadeOnDelete();
            $table->uuid('product_id');
            $table->string('product_name');
            $table->string('hsn_code');
            $table->integer('quantity');
            $table->bigInteger('unit_rate');    // paise
            $table->bigInteger('discount');     // paise
            $table->decimal('gst_rate', 5, 2);
            $table->bigInteger('cgst');         // paise
            $table->bigInteger('sgst');         // paise
            $table->bigInteger('igst');         // paise
            $table->bigInteger('line_total');   // paise
            $table->timestamps();

            $table->index('sales_invoice_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_line_items');
    }
};
