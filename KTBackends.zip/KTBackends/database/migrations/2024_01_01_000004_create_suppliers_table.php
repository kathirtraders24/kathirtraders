<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('suppliers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('gstin', 15);
            $table->string('phone', 15);
            $table->string('email')->nullable();
            $table->text('address');
            $table->string('state_code', 2);
            $table->string('payment_terms');
            $table->timestamps();
            $table->softDeletes();

            $table->index('name');
            $table->index('gstin');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('suppliers');
    }
};
