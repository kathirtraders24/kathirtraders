<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_line_items', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('order_id')->constrained('orders')->cascadeOnDelete();
            $table->uuid('product_id');
            $table->string('name');
            $table->string('hsn_code');
            $table->integer('quantity');
            $table->bigInteger('unit_price');   // paise
            $table->bigInteger('discount');     // paise
            $table->bigInteger('total_price');  // paise
            $table->timestamps();

            $table->index('order_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_line_items');
    }
};
