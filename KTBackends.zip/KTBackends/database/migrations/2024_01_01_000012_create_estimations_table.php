<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('estimations', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('estimation_number')->unique();
            $table->date('date');
            $table->date('valid_until');
            $table->foreignUuid('customer_id')->nullable()->constrained('customers')->nullOnDelete();
            $table->string('customer_name');
            $table->text('customer_address');
            $table->string('customer_phone', 15);
            $table->string('customer_gstin', 15)->nullable();
            $table->bigInteger('sub_total');    // paise
            $table->bigInteger('total_cgst');   // paise
            $table->bigInteger('total_sgst');   // paise
            $table->bigInteger('total_igst');   // paise
            $table->bigInteger('grand_total');  // paise
            $table->text('notes')->nullable();
            $table->enum('status', ['draft', 'sent', 'accepted', 'rejected', 'expired'])->default('draft');
            $table->timestamps();
            $table->softDeletes();

            $table->index('date');
            $table->index('status');
            $table->index('customer_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('estimations');
    }
};
