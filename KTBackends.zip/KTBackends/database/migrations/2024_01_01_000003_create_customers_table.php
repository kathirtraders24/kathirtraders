<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('gstin', 15)->nullable();
            $table->string('phone', 15);
            $table->string('email')->nullable();
            $table->text('address');
            $table->string('state_code', 2);
            $table->bigInteger('credit_limit')->default(0);       // paise
            $table->bigInteger('outstanding_balance')->default(0); // paise
            $table->timestamps();
            $table->softDeletes();

            $table->index('name');
            $table->index('phone');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('customers');
    }
};
