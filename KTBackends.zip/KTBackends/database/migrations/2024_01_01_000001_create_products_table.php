<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('sku')->unique();
            $table->string('name');
            $table->enum('category', ['plumbing', 'electrical']);
            $table->string('sub_category');
            $table->string('unit');
            $table->string('hsn_code');
            $table->decimal('gst_rate', 5, 2);
            $table->bigInteger('unit_price');   // stored in paise
            $table->text('description')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['category', 'sub_category']);
            $table->index('name');
            $table->index('hsn_code');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
