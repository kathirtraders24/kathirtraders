<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('customer_name');
            $table->string('customer_phone', 15);
            $table->date('date');
            $table->bigInteger('grand_total');  // paise
            $table->enum('payment_status', ['paid', 'partial', 'unpaid'])->default('unpaid');
            $table->timestamps();

            $table->index('date');
            $table->index('payment_status');
            $table->index('customer_phone');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
