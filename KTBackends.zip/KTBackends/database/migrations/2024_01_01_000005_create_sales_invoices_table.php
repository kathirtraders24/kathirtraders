<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sales_invoices', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('invoice_number')->unique();
            $table->date('date');
            $table->foreignUuid('customer_id')->constrained('customers');
            $table->string('customer_name');
            $table->bigInteger('sub_total');    // paise
            $table->bigInteger('total_cgst');   // paise
            $table->bigInteger('total_sgst');   // paise
            $table->bigInteger('total_igst');   // paise
            $table->bigInteger('grand_total');  // paise
            $table->enum('payment_mode', ['cash', 'upi', 'cheque', 'neft', 'credit']);
            $table->enum('status', ['draft', 'confirmed', 'cancelled'])->default('draft');
            $table->timestamps();
            $table->softDeletes();

            $table->index('date');
            $table->index('status');
            $table->index('customer_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sales_invoices');
    }
};
