<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('purchase_orders', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('po_number')->unique();
            $table->date('date');
            $table->foreignUuid('supplier_id')->constrained('suppliers');
            $table->string('supplier_name');
            $table->bigInteger('total_amount');  // paise
            $table->enum('status', ['draft', 'ordered', 'received', 'cancelled'])->default('draft');
            $table->timestamps();
            $table->softDeletes();

            $table->index('date');
            $table->index('status');
            $table->index('supplier_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('purchase_orders');
    }
};
