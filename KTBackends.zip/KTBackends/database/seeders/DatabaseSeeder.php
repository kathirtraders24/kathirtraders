<?php

namespace Database\Seeders;

use App\Models\Customer;
use App\Models\Product;
use App\Models\StockEntry;
use App\Models\Supplier;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Sample Products
        $products = [
            [
                'id'           => Str::uuid(),
                'sku'          => 'PLMB-001',
                'name'         => 'CPVC Pipe 1/2 inch',
                'category'     => 'plumbing',
                'sub_category' => 'Pipes',
                'unit'         => 'meter',
                'hsn_code'     => '3917',
                'gst_rate'     => 18,
                'unit_price'   => 4500,  // ₹45.00 in paise
                'description'  => 'CPVC pipe 1/2 inch diameter',
            ],
            [
                'id'           => Str::uuid(),
                'sku'          => 'PLMB-002',
                'name'         => 'PVC Ball Valve 3/4 inch',
                'category'     => 'plumbing',
                'sub_category' => 'Valves',
                'unit'         => 'piece',
                'hsn_code'     => '8481',
                'gst_rate'     => 18,
                'unit_price'   => 18000,  // ₹180.00 in paise
                'description'  => 'PVC ball valve 3/4 inch',
            ],
            [
                'id'           => Str::uuid(),
                'sku'          => 'ELEC-001',
                'name'         => 'Copper Wire 2.5mm 90m Roll',
                'category'     => 'electrical',
                'sub_category' => 'Wires & Cables',
                'unit'         => 'roll',
                'hsn_code'     => '8544',
                'gst_rate'     => 18,
                'unit_price'   => 280000,  // ₹2800.00 in paise
                'description'  => '2.5mm copper wire, 90m roll',
            ],
            [
                'id'           => Str::uuid(),
                'sku'          => 'ELEC-002',
                'name'         => 'MCB 32A Single Pole',
                'category'     => 'electrical',
                'sub_category' => 'Circuit Breakers',
                'unit'         => 'piece',
                'hsn_code'     => '8536',
                'gst_rate'     => 18,
                'unit_price'   => 35000,  // ₹350.00 in paise
                'description'  => 'MCB 32 Amp single pole',
            ],
            [
                'id'           => Str::uuid(),
                'sku'          => 'PLMB-003',
                'name'         => 'Gate Valve 1 inch ISI',
                'category'     => 'plumbing',
                'sub_category' => 'Valves',
                'unit'         => 'piece',
                'hsn_code'     => '8481',
                'gst_rate'     => 18,
                'unit_price'   => 22000,  // ₹220.00 in paise
                'description'  => 'Gate valve 1 inch ISI marked',
            ],
        ];

        foreach ($products as $productData) {
            $product = Product::create($productData);
            StockEntry::create([
                'product_id'         => $product->id,
                'warehouse_location' => 'Main Warehouse',
                'quantity_on_hand'   => rand(20, 200),
                'reorder_level'      => 10,
            ]);
        }

        // Sample Customers
        Customer::insert([
            [
                'id'                  => Str::uuid(),
                'name'                => 'Ravi Construction Co',
                'gstin'               => '33AABCR1234A1Z5',
                'phone'               => '9876543210',
                'email'               => 'ravi@raviconstruction.in',
                'address'             => '12, Anna Salai, Chennai - 600002',
                'state_code'          => '33',
                'credit_limit'        => 50000000,   // ₹5,00,000
                'outstanding_balance' => 0,
                'created_at'          => now(),
                'updated_at'          => now(),
            ],
            [
                'id'                  => Str::uuid(),
                'name'                => 'Murugan Electricals',
                'gstin'               => null,
                'phone'               => '9944112233',
                'email'               => null,
                'address'             => '45, Gandhi Road, Coimbatore - 641001',
                'state_code'          => '33',
                'credit_limit'        => 10000000,   // ₹1,00,000
                'outstanding_balance' => 0,
                'created_at'          => now(),
                'updated_at'          => now(),
            ],
        ]);

        // Sample Suppliers
        Supplier::insert([
            [
                'id'            => Str::uuid(),
                'name'          => 'Supreme Industries Ltd',
                'gstin'         => '27AAACS1234B1Z1',
                'phone'         => '02225234567',
                'email'         => 'sales@supreme.in',
                'address'       => 'Supreme House, Mumbai - 400054',
                'state_code'    => '27',
                'payment_terms' => 'Net 30',
                'created_at'    => now(),
                'updated_at'    => now(),
            ],
            [
                'id'            => Str::uuid(),
                'name'          => 'Finolex Cables Ltd',
                'gstin'         => '27AAACF5678C1Z2',
                'phone'         => '02025678901',
                'email'         => 'orders@finolex.com',
                'address'       => 'Finolex House, Pune - 411001',
                'state_code'    => '27',
                'payment_terms' => 'Net 45',
                'created_at'    => now(),
                'updated_at'    => now(),
            ],
        ]);
    }
}
