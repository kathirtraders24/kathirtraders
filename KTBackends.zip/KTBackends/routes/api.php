<?php

use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\EstimationController;
use App\Http\Controllers\Api\InvoiceController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\PurchaseController;
use App\Http\Controllers\Api\StockController;
use App\Http\Controllers\Api\SupplierController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Kathir Traders API Routes
|--------------------------------------------------------------------------
| All routes are prefixed with /api automatically by Laravel 11.
*/

// Customers
Route::apiResource('customers', CustomerController::class);

// Suppliers
Route::apiResource('suppliers', SupplierController::class);

// Products (with search via ?q=term)
Route::apiResource('products', ProductController::class);

// Stock Management
Route::prefix('stock')->group(function () {
    Route::get('/',                    [StockController::class, 'index']);
    Route::get('/low',                 [StockController::class, 'lowStock']);
    Route::get('/check',               [StockController::class, 'checkAvailability']);
    Route::get('/product/{productId}', [StockController::class, 'byProduct']);
    Route::post('/adjust',             [StockController::class, 'adjust']);
});

// Sales Invoices
Route::apiResource('invoices', InvoiceController::class)->only(['index', 'show', 'store']);
Route::post('invoices/{invoice}/confirm', [InvoiceController::class, 'confirm']);
Route::post('invoices/{invoice}/cancel',  [InvoiceController::class, 'cancel']);

// Purchase Orders
Route::apiResource('purchases', PurchaseController::class)->only(['index', 'show', 'store']);
Route::post('purchases/{purchase}/receive', [PurchaseController::class, 'markReceived']);
Route::post('purchases/{purchase}/cancel',  [PurchaseController::class, 'cancel']);

// Retail Orders (POS)
Route::apiResource('orders', OrderController::class)->only(['index', 'show', 'store']);

// Estimations
Route::apiResource('estimations', EstimationController::class)
    ->except(['update'])
    ->names('estimations');
Route::patch('estimations/{estimation}', [EstimationController::class, 'update']);
