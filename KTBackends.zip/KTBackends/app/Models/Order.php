<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    use HasUuids;

    protected $fillable = [
        'customer_name',
        'customer_phone',
        'date',
        'grand_total',
        'payment_status',
    ];

    protected $casts = [
        'date' => 'date',
        'grand_total' => 'integer',
    ];

    public function lines(): HasMany
    {
        return $this->hasMany(OrderLineItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(PaymentSplit::class);
    }
}
