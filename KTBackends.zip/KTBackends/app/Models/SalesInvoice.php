<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class SalesInvoice extends Model
{
    use HasUuids, SoftDeletes;

    protected $fillable = [
        'invoice_number',
        'date',
        'customer_id',
        'customer_name',
        'sub_total',
        'total_cgst',
        'total_sgst',
        'total_igst',
        'grand_total',
        'payment_mode',
        'status',
    ];

    protected $casts = [
        'date' => 'date',
        'sub_total' => 'integer',
        'total_cgst' => 'integer',
        'total_sgst' => 'integer',
        'total_igst' => 'integer',
        'grand_total' => 'integer',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function lines(): HasMany
    {
        return $this->hasMany(InvoiceLineItem::class);
    }
}
