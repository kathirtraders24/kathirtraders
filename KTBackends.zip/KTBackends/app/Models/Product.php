<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasUuids, SoftDeletes;

    protected $fillable = [
        'sku',
        'name',
        'category',
        'sub_category',
        'unit',
        'hsn_code',
        'gst_rate',
        'unit_price',
        'description',
    ];

    protected $casts = [
        'gst_rate' => 'float',
        'unit_price' => 'integer',
    ];

    public function stock(): HasOne
    {
        return $this->hasOne(StockEntry::class);
    }

    public function scopeSearch($query, string $term)
    {
        return $query->where(function ($q) use ($term) {
            $q->where('name', 'ilike', "%{$term}%")
              ->orWhere('sku', 'ilike', "%{$term}%")
              ->orWhere('category', 'ilike', "%{$term}%")
              ->orWhere('hsn_code', 'ilike', "%{$term}%");
        });
    }
}
