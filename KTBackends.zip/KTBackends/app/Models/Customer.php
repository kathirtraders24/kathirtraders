<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use HasUuids, SoftDeletes;

    protected $fillable = [
        'name',
        'gstin',
        'phone',
        'email',
        'address',
        'state_code',
        'credit_limit',
        'outstanding_balance',
    ];

    protected $casts = [
        'credit_limit' => 'integer',
        'outstanding_balance' => 'integer',
    ];

    public function invoices(): HasMany
    {
        return $this->hasMany(SalesInvoice::class);
    }

    public function estimations(): HasMany
    {
        return $this->hasMany(Estimation::class);
    }
}
