<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InvoiceLineItem extends Model
{
    use HasUuids;

    protected $fillable = [
        'sales_invoice_id',
        'product_id',
        'product_name',
        'hsn_code',
        'quantity',
        'unit_rate',
        'discount',
        'gst_rate',
        'cgst',
        'sgst',
        'igst',
        'line_total',
    ];

    protected $casts = [
        'quantity' => 'integer',
        'unit_rate' => 'integer',
        'discount' => 'integer',
        'gst_rate' => 'float',
        'cgst' => 'integer',
        'sgst' => 'integer',
        'igst' => 'integer',
        'line_total' => 'integer',
    ];

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(SalesInvoice::class, 'sales_invoice_id');
    }
}
