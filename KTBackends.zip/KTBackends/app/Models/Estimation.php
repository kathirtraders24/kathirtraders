<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Estimation extends Model
{
    use HasUuids, SoftDeletes;

    protected $fillable = [
        'estimation_number',
        'date',
        'valid_until',
        'customer_id',
        'customer_name',
        'customer_address',
        'customer_phone',
        'customer_gstin',
        'sub_total',
        'total_cgst',
        'total_sgst',
        'total_igst',
        'grand_total',
        'notes',
        'status',
    ];

    protected $casts = [
        'date' => 'date',
        'valid_until' => 'date',
        'sub_total' => 'integer',
        'total_cgst' => 'integer',
        'total_sgst' => 'integer',
        'total_igst' => 'integer',
        'grand_total' => 'integer',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function lines(): HasMany
    {
        return $this->hasMany(EstimationLineItem::class);
    }
}
