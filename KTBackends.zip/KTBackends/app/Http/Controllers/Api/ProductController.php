<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Product::with('stock');

        if ($search = $request->query('q')) {
            $query->search($search);
        }

        return response()->json($query->orderBy('name')->get());
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json($product->load('stock'));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'sku'          => 'required|string|max:100|unique:products,sku',
            'name'         => 'required|string|max:255',
            'category'     => 'required|in:plumbing,electrical',
            'sub_category' => 'required|string|max:100',
            'unit'         => 'required|string|max:50',
            'hsn_code'     => 'required|string|max:20',
            'gst_rate'     => 'required|numeric|min:0|max:100',
            'unit_price'   => 'required|integer|min:0',
            'description'  => 'nullable|string',
        ]);

        $product = Product::create($validated);

        // Auto-create a stock entry with zero stock
        $product->stock()->create([
            'warehouse_location' => 'Main Warehouse',
            'quantity_on_hand'   => 0,
            'reorder_level'      => 10,
        ]);

        return response()->json($product->load('stock'), 201);
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'sku'          => 'sometimes|string|max:100|unique:products,sku,'.$product->id,
            'name'         => 'sometimes|string|max:255',
            'category'     => 'sometimes|in:plumbing,electrical',
            'sub_category' => 'sometimes|string|max:100',
            'unit'         => 'sometimes|string|max:50',
            'hsn_code'     => 'sometimes|string|max:20',
            'gst_rate'     => 'sometimes|numeric|min:0|max:100',
            'unit_price'   => 'sometimes|integer|min:0',
            'description'  => 'nullable|string',
        ]);

        $product->update($validated);

        return response()->json($product->load('stock'));
    }

    public function destroy(Product $product): JsonResponse
    {
        $product->delete();

        return response()->json(null, 204);
    }
}
