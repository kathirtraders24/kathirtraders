<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\StockEntry;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class StockController extends Controller
{
    public function index(): JsonResponse
    {
        $stock = StockEntry::with('product')->orderBy('created_at')->get();

        return response()->json($stock);
    }

    public function byProduct(string $productId): JsonResponse
    {
        $entry = StockEntry::with('product')
            ->where('product_id', $productId)
            ->firstOrFail();

        return response()->json($entry);
    }

    public function checkAvailability(Request $request): JsonResponse
    {
        $request->validate([
            'productId' => 'required|uuid|exists:products,id',
            'quantity'  => 'required|integer|min:1',
        ]);

        $entry = StockEntry::where('product_id', $request->productId)->first();

        if (! $entry) {
            return response()->json(['available' => false, 'quantity_on_hand' => 0]);
        }

        return response()->json([
            'available'        => $entry->quantity_on_hand >= (int) $request->quantity,
            'quantity_on_hand' => $entry->quantity_on_hand,
        ]);
    }

    public function adjust(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'productId' => 'required|uuid|exists:products,id',
            'quantity'  => 'required|integer',   // positive = add, negative = subtract
            'reason'    => 'required|string|max:255',
        ]);

        $entry = StockEntry::firstOrCreate(
            ['product_id' => $validated['productId']],
            ['warehouse_location' => 'Main Warehouse', 'quantity_on_hand' => 0, 'reorder_level' => 10]
        );

        $newQty = $entry->quantity_on_hand + $validated['quantity'];

        if ($newQty < 0) {
            return response()->json(['message' => 'Insufficient stock'], 422);
        }

        $entry->update(['quantity_on_hand' => $newQty]);

        return response()->json($entry->load('product'));
    }

    public function lowStock(): JsonResponse
    {
        $low = StockEntry::with('product')->lowStock()->get();

        return response()->json($low);
    }
}
