<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SalesInvoice;
use App\Models\StockEntry;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller
{
    public function index(): JsonResponse
    {
        $invoices = SalesInvoice::with('lines')
            ->orderByDesc('date')
            ->orderByDesc('created_at')
            ->get();

        return response()->json($invoices);
    }

    public function show(SalesInvoice $invoice): JsonResponse
    {
        return response()->json($invoice->load('lines', 'customer'));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'date'                  => 'required|date',
            'customer_id'           => 'required|uuid|exists:customers,id',
            'customer_name'         => 'required|string|max:255',
            'lines'                 => 'required|array|min:1',
            'lines.*.product_id'    => 'required|uuid',
            'lines.*.product_name'  => 'required|string',
            'lines.*.hsn_code'      => 'required|string',
            'lines.*.quantity'      => 'required|integer|min:1',
            'lines.*.unit_rate'     => 'required|integer|min:0',
            'lines.*.discount'      => 'required|integer|min:0',
            'lines.*.gst_rate'      => 'required|numeric|min:0',
            'lines.*.cgst'          => 'required|integer|min:0',
            'lines.*.sgst'          => 'required|integer|min:0',
            'lines.*.igst'          => 'required|integer|min:0',
            'lines.*.line_total'    => 'required|integer|min:0',
            'sub_total'             => 'required|integer|min:0',
            'total_cgst'            => 'required|integer|min:0',
            'total_sgst'            => 'required|integer|min:0',
            'total_igst'            => 'required|integer|min:0',
            'grand_total'           => 'required|integer|min:0',
            'payment_mode'          => 'required|in:cash,upi,cheque,neft,credit',
        ]);

        $invoice = DB::transaction(function () use ($validated) {
            $invoiceNumber = $this->generateInvoiceNumber();

            $invoice = SalesInvoice::create([
                'invoice_number' => $invoiceNumber,
                'date'           => $validated['date'],
                'customer_id'    => $validated['customer_id'],
                'customer_name'  => $validated['customer_name'],
                'sub_total'      => $validated['sub_total'],
                'total_cgst'     => $validated['total_cgst'],
                'total_sgst'     => $validated['total_sgst'],
                'total_igst'     => $validated['total_igst'],
                'grand_total'    => $validated['grand_total'],
                'payment_mode'   => $validated['payment_mode'],
                'status'         => 'draft',
            ]);

            foreach ($validated['lines'] as $line) {
                $invoice->lines()->create($line);
            }

            return $invoice;
        });

        return response()->json($invoice->load('lines'), 201);
    }

    public function confirm(SalesInvoice $invoice): JsonResponse
    {
        if ($invoice->status !== 'draft') {
            return response()->json(['message' => 'Only draft invoices can be confirmed'], 422);
        }

        DB::transaction(function () use ($invoice) {
            // Deduct stock for each line item
            foreach ($invoice->lines as $line) {
                $stock = StockEntry::where('product_id', $line->product_id)->first();
                if ($stock) {
                    $newQty = $stock->quantity_on_hand - $line->quantity;
                    if ($newQty < 0) {
                        throw new \Exception("Insufficient stock for product: {$line->product_name}");
                    }
                    $stock->update(['quantity_on_hand' => $newQty]);
                }
            }

            $invoice->update(['status' => 'confirmed']);
        });

        return response()->json($invoice->fresh()->load('lines'));
    }

    public function cancel(SalesInvoice $invoice): JsonResponse
    {
        if ($invoice->status === 'cancelled') {
            return response()->json(['message' => 'Invoice is already cancelled'], 422);
        }

        DB::transaction(function () use ($invoice) {
            // If it was confirmed, restore stock
            if ($invoice->status === 'confirmed') {
                foreach ($invoice->lines as $line) {
                    $stock = StockEntry::where('product_id', $line->product_id)->first();
                    if ($stock) {
                        $stock->increment('quantity_on_hand', $line->quantity);
                    }
                }
            }

            $invoice->update(['status' => 'cancelled']);
        });

        return response()->json($invoice->fresh()->load('lines'));
    }

    private function generateInvoiceNumber(): string
    {
        $prefix = 'INV-' . date('Y') . '-';
        $last = SalesInvoice::where('invoice_number', 'like', $prefix . '%')
            ->orderByDesc('invoice_number')
            ->value('invoice_number');

        $seq = $last ? (int) substr($last, strlen($prefix)) + 1 : 1;

        return $prefix . str_pad($seq, 5, '0', STR_PAD_LEFT);
    }
}
