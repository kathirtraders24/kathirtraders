<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Supplier;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SupplierController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(Supplier::orderBy('name')->get());
    }

    public function show(Supplier $supplier): JsonResponse
    {
        return response()->json($supplier);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name'          => 'required|string|max:255',
            'gstin'         => 'required|string|max:15',
            'phone'         => 'required|string|max:15',
            'email'         => 'nullable|email|max:255',
            'address'       => 'required|string',
            'state_code'    => 'required|string|size:2',
            'payment_terms' => 'required|string|max:255',
        ]);

        $supplier = Supplier::create($validated);

        return response()->json($supplier, 201);
    }

    public function update(Request $request, Supplier $supplier): JsonResponse
    {
        $validated = $request->validate([
            'name'          => 'sometimes|string|max:255',
            'gstin'         => 'sometimes|string|max:15',
            'phone'         => 'sometimes|string|max:15',
            'email'         => 'nullable|email|max:255',
            'address'       => 'sometimes|string',
            'state_code'    => 'sometimes|string|size:2',
            'payment_terms' => 'sometimes|string|max:255',
        ]);

        $supplier->update($validated);

        return response()->json($supplier);
    }

    public function destroy(Supplier $supplier): JsonResponse
    {
        $supplier->delete();

        return response()->json(null, 204);
    }
}
