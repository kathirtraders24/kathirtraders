<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PurchaseOrder;
use App\Models\StockEntry;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{
    public function index(): JsonResponse
    {
        $orders = PurchaseOrder::with('lines')
            ->orderByDesc('date')
            ->orderByDesc('created_at')
            ->get();

        return response()->json($orders);
    }

    public function show(PurchaseOrder $purchase): JsonResponse
    {
        return response()->json($purchase->load('lines', 'supplier'));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'date'                  => 'required|date',
            'supplier_id'           => 'required|uuid|exists:suppliers,id',
            'supplier_name'         => 'required|string|max:255',
            'lines'                 => 'required|array|min:1',
            'lines.*.product_id'    => 'required|uuid',
            'lines.*.product_name'  => 'required|string',
            'lines.*.quantity'      => 'required|integer|min:1',
            'lines.*.unit_rate'     => 'required|integer|min:0',
            'lines.*.line_total'    => 'required|integer|min:0',
            'total_amount'          => 'required|integer|min:0',
        ]);

        $order = DB::transaction(function () use ($validated) {
            $poNumber = $this->generatePoNumber();

            $order = PurchaseOrder::create([
                'po_number'     => $poNumber,
                'date'          => $validated['date'],
                'supplier_id'   => $validated['supplier_id'],
                'supplier_name' => $validated['supplier_name'],
                'total_amount'  => $validated['total_amount'],
                'status'        => 'draft',
            ]);

            foreach ($validated['lines'] as $line) {
                $order->lines()->create($line);
            }

            return $order;
        });

        return response()->json($order->load('lines'), 201);
    }

    public function markReceived(PurchaseOrder $purchase): JsonResponse
    {
        if ($purchase->status !== 'ordered' && $purchase->status !== 'draft') {
            return response()->json(['message' => 'Only draft or ordered purchases can be received'], 422);
        }

        DB::transaction(function () use ($purchase) {
            // Add stock for each line received
            foreach ($purchase->lines as $line) {
                $stock = StockEntry::firstOrCreate(
                    ['product_id' => $line->product_id],
                    ['warehouse_location' => 'Main Warehouse', 'quantity_on_hand' => 0, 'reorder_level' => 10]
                );
                $stock->increment('quantity_on_hand', $line->quantity);
            }

            $purchase->update(['status' => 'received']);
        });

        return response()->json($purchase->fresh()->load('lines'));
    }

    public function cancel(PurchaseOrder $purchase): JsonResponse
    {
        if ($purchase->status === 'cancelled') {
            return response()->json(['message' => 'Purchase order is already cancelled'], 422);
        }

        if ($purchase->status === 'received') {
            return response()->json(['message' => 'Received purchase orders cannot be cancelled'], 422);
        }

        $purchase->update(['status' => 'cancelled']);

        return response()->json($purchase->fresh()->load('lines'));
    }

    private function generatePoNumber(): string
    {
        $prefix = 'PO-' . date('Y') . '-';
        $last = PurchaseOrder::where('po_number', 'like', $prefix . '%')
            ->orderByDesc('po_number')
            ->value('po_number');

        $seq = $last ? (int) substr($last, strlen($prefix)) + 1 : 1;

        return $prefix . str_pad($seq, 5, '0', STR_PAD_LEFT);
    }
}
