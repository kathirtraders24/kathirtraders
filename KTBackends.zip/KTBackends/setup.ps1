# Kathir Traders Backend Setup Script (Windows PowerShell)
# Run this script from the kt-backend directory

Write-Host "=== Kathir Traders Backend Setup ===" -ForegroundColor Cyan

# 1. Check prerequisites
Write-Host "`n[1/6] Checking prerequisites..." -ForegroundColor Yellow
$phpVersion = php --version 2>$null
if (-not $?) {
    Write-Host "ERROR: PHP not found. Install PHP 8.2+ from https://windows.php.net/" -ForegroundColor Red
    exit 1
}
Write-Host "PHP: OK" -ForegroundColor Green

$composerVersion = composer --version 2>$null
if (-not $?) {
    Write-Host "ERROR: Composer not found. Install from https://getcomposer.org/" -ForegroundColor Red
    exit 1
}
Write-Host "Composer: OK" -ForegroundColor Green

# 2. Install dependencies
Write-Host "`n[2/6] Installing Composer dependencies..." -ForegroundColor Yellow
composer install --no-interaction

# 3. Copy .env
Write-Host "`n[3/6] Creating .env file..." -ForegroundColor Yellow
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host ".env created from .env.example" -ForegroundColor Green
} else {
    Write-Host ".env already exists, skipping" -ForegroundColor Gray
}

# 4. Generate app key
Write-Host "`n[4/6] Generating application key..." -ForegroundColor Yellow
php artisan key:generate

# 5. Create PostgreSQL database
Write-Host "`n[5/6] Database setup..." -ForegroundColor Yellow
Write-Host "Please ensure PostgreSQL is running and create the database manually:" -ForegroundColor Cyan
Write-Host "  psql -U postgres -c `"CREATE DATABASE kt_traders;`"" -ForegroundColor White
Write-Host ""
Write-Host "Then update DB_PASSWORD in .env if needed." -ForegroundColor Cyan
Read-Host "Press Enter when database is ready"

# 6. Run migrations and seed
Write-Host "`n[6/6] Running migrations and seeder..." -ForegroundColor Yellow
php artisan migrate --seed

Write-Host "`n=== Setup Complete! ===" -ForegroundColor Green
Write-Host "Start the server with: php artisan serve" -ForegroundColor Cyan
Write-Host "API will be available at: http://localhost:8000/api" -ForegroundColor Cyan
