#!/bin/bash
# Kathir Traders Backend Setup Script (Linux/Mac)

set -e

echo "=== Kathir Traders Backend Setup ==="

echo ""
echo "[1/6] Checking prerequisites..."
php --version || { echo "ERROR: PHP 8.2+ required"; exit 1; }
composer --version || { echo "ERROR: Composer required"; exit 1; }

echo ""
echo "[2/6] Installing dependencies..."
composer install --no-interaction

echo ""
echo "[3/6] Creating .env file..."
[ -f .env ] || cp .env.example .env

echo ""
echo "[4/6] Generating app key..."
php artisan key:generate

echo ""
echo "[5/6] Database: ensure PostgreSQL is running, then:"
echo "  createdb kt_traders   (or)   psql -U postgres -c 'CREATE DATABASE kt_traders;'"
echo "  Update DB_USERNAME / DB_PASSWORD in .env if needed."
read -p "Press Enter when database is ready..."

echo ""
echo "[6/6] Running migrations and seeder..."
php artisan migrate --seed

echo ""
echo "=== Setup Complete! ==="
echo "Start server: php artisan serve"
echo "API URL:      http://localhost:8000/api"
