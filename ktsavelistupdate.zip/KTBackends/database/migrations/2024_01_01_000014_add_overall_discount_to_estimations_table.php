<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('estimations', function (Blueprint $table) {
            // Estimation-level (not per-line) discount, so it round-trips on reload.
            $table->string('overall_discount_type')->default('flat')->after('grand_total');   // 'flat' | 'percent'
            $table->decimal('overall_discount_value', 12, 2)->default(0)->after('overall_discount_type'); // percent number or rupees number
            $table->bigInteger('overall_discount')->default(0)->after('overall_discount_value'); // paise
        });
    }

    public function down(): void
    {
        Schema::table('estimations', function (Blueprint $table) {
            $table->dropColumn(['overall_discount_type', 'overall_discount_value', 'overall_discount']);
        });
    }
};
