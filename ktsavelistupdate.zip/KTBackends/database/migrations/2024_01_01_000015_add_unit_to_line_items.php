<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoice_line_items', function (Blueprint $table) {
            $table->string('unit', 20)->default('Nos')->after('quantity'); // Nos, Mtr, Kg, ...
        });

        Schema::table('estimation_line_items', function (Blueprint $table) {
            $table->string('unit', 20)->default('Nos')->after('quantity');
        });
    }

    public function down(): void
    {
        Schema::table('invoice_line_items', function (Blueprint $table) {
            $table->dropColumn('unit');
        });

        Schema::table('estimation_line_items', function (Blueprint $table) {
            $table->dropColumn('unit');
        });
    }
};
