<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index(): JsonResponse
    {
        $orders = Order::with('lines', 'payments')
            ->orderByDesc('date')
            ->orderByDesc('created_at')
            ->get();

        return response()->json($orders);
    }

    public function show(Order $order): JsonResponse
    {
        return response()->json($order->load('lines', 'payments'));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'customer_name'           => 'required|string|max:255',
            'customer_phone'          => 'required|string|max:15',
            'date'                    => 'required|date',
            'lines'                   => 'required|array|min:1',
            'lines.*.product_id'      => 'required|uuid',
            'lines.*.name'            => 'required|string',
            'lines.*.hsn_code'        => 'nullable|string',
            'lines.*.quantity'        => 'required|integer|min:1',
            'lines.*.unit'            => 'nullable|string|max:20',
            'lines.*.unit_price'      => 'required|integer|min:0',
            'lines.*.discount'        => 'required|integer|min:0',
            'lines.*.total_price'     => 'required|integer|min:0',
            'grand_total'             => 'required|integer|min:0',
            'payment_status'          => 'required|in:paid,partial,unpaid',
            'payments'                => 'required|array',
            'payments.*.mode'         => 'required|in:cash,upi,cheque,neft,credit',
            'payments.*.amount'       => 'required|integer|min:0',
        ]);

        $order = DB::transaction(function () use ($validated) {
            $order = Order::create([
                'order_number'   => $this->generateOrderNumber(),
                'customer_name'  => $validated['customer_name'],
                'customer_phone' => $validated['customer_phone'],
                'date'           => $validated['date'],
                'grand_total'    => $validated['grand_total'],
                'payment_status' => $validated['payment_status'],
            ]);

            foreach ($validated['lines'] as $line) {
                $line['hsn_code'] = $line['hsn_code'] ?? '';
                $line['unit'] = $line['unit'] ?? 'Nos';
                $order->lines()->create($line);
            }

            foreach ($validated['payments'] as $payment) {
                $order->payments()->create($payment);
            }

            return $order;
        });

        return response()->json($order->load('lines', 'payments'), 201);
    }

    private function generateOrderNumber(): string
    {
        $prefix = 'INV-' . date('Y') . '-';
        $last = Order::where('order_number', 'like', $prefix . '%')
            ->orderByDesc('order_number')
            ->value('order_number');

        $seq = $last ? (int) substr($last, strlen($prefix)) + 1 : 1;

        return $prefix . str_pad($seq, 5, '0', STR_PAD_LEFT);
    }
}
