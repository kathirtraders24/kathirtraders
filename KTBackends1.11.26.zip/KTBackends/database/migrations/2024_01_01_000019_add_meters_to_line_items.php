<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private array $tables = [
        'invoice_line_items',
        'estimation_line_items',
        'order_line_items',
        'purchase_order_lines',
    ];

    public function up(): void
    {
        foreach ($this->tables as $table) {
            Schema::table($table, function (Blueprint $t) {
                // Optional length in metres for length-based products (e.g. pipes).
                // Total = unit price × quantity × metres when present.
                $t->decimal('meters', 10, 2)->nullable()->after('quantity');
            });
        }
    }

    public function down(): void
    {
        foreach ($this->tables as $table) {
            Schema::table($table, function (Blueprint $t) {
                $t->dropColumn('meters');
            });
        }
    }
};
