<?php

namespace App\Services;

use App\Models\DocumentCounter;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

/**
 * Issues sequential, collision-free document numbers (INV-YYYY-00001, etc.).
 *
 * A single atomic counter backs each series/year, so:
 *  - POS orders and tax invoices share one INV series and can never duplicate;
 *  - concurrent creates / double-submits can't produce the same number
 *    (the counter row is locked for the duration of the increment).
 */
class DocumentNumberService
{
    /**
     * Prefix => tables/columns holding legacy numbers for that series.
     * Used only to seed the counter the first time, so existing numbers
     * are never re-issued. Soft-deleted rows are included on purpose.
     */
    private const SOURCES = [
        'INV' => [['orders', 'order_number'], ['sales_invoices', 'invoice_number']],
        'EST' => [['estimations', 'estimation_number']],
        'PO'  => [['purchase_orders', 'po_number']],
    ];

    public function next(string $prefix): string
    {
        $year = date('Y');
        $key  = "{$prefix}-{$year}";

        $value = DB::transaction(function () use ($prefix, $year, $key) {
            $counter = DocumentCounter::where('key', $key)->lockForUpdate()->first();

            if (! $counter) {
                // First document of this series/year. Two concurrent requests can
                // both reach here; the unique `key` lets only one insert win, and
                // the loser re-reads the now-existing row under a lock.
                try {
                    DocumentCounter::create([
                        'key'   => $key,
                        'value' => $this->maxExisting($prefix, $year),
                    ]);
                } catch (QueryException $e) {
                    // Row was created concurrently — fall through and lock it below.
                }

                $counter = DocumentCounter::where('key', $key)->lockForUpdate()->first();
            }

            $counter->value += 1;
            $counter->save();

            return $counter->value;
        });

        return sprintf('%s-%s-%05d', $prefix, $year, $value);
    }

    /** Highest sequence already used for this prefix/year across all source tables. */
    private function maxExisting(string $prefix, string $year): int
    {
        $like = "{$prefix}-{$year}-%";
        $max  = 0;

        foreach (self::SOURCES[$prefix] ?? [] as [$table, $column]) {
            $latest = DB::table($table)
                ->where($column, 'like', $like)
                ->orderByDesc($column)
                ->value($column);

            if ($latest) {
                $max = max($max, (int) substr($latest, strlen("{$prefix}-{$year}-")));
            }
        }

        return $max;
    }
}
