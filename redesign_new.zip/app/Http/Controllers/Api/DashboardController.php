<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\SalesInvoice;
use App\Models\StockEntry;
use App\Models\Supplier;
use Carbon\CarbonPeriod;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    public function summary(): JsonResponse
    {
        $today = now()->toDateString();

        $todaySales = (int) Order::whereDate('date', $today)->sum('grand_total')
            + (int) SalesInvoice::where('status', 'confirmed')->whereDate('date', $today)->sum('grand_total');

        return response()->json([
            'products_count'   => Product::count(),
            'today_sales'      => $todaySales,
            'pending_orders'   => PurchaseOrder::whereIn('status', ['draft', 'ordered'])->count(),
            'customers_count'  => Customer::count(),
            'low_stock_count'  => StockEntry::lowStock()->count(),
            'suppliers_count'  => Supplier::count(),
            'revenue_series'   => $this->revenueSeries(),
        ]);
    }

    private function revenueSeries(): array
    {
        // Use date-only boundaries: the `date` column has no time component, so a
        // datetime boundary (e.g. "…-06 00:00:00") would drop the earliest day on
        // SQLite's string comparison. Date strings compare correctly everywhere.
        $start = now()->subDays(6)->startOfDay();
        $end   = now()->endOfDay();
        $startDate = $start->toDateString();
        $endDate   = $end->toDateString();

        $orderTotals = Order::whereBetween('date', [$startDate, $endDate])
            ->selectRaw('DATE(date) as d, SUM(grand_total) as total')
            ->groupBy('d')
            ->pluck('total', 'd');

        $invoiceTotals = SalesInvoice::where('status', 'confirmed')
            ->whereBetween('date', [$startDate, $endDate])
            ->selectRaw('DATE(date) as d, SUM(grand_total) as total')
            ->groupBy('d')
            ->pluck('total', 'd');

        $series = [];
        foreach (CarbonPeriod::create($start, $end) as $day) {
            $key = $day->toDateString();
            $series[] = [
                'date'  => $key,
                'total' => (int) ($orderTotals[$key] ?? 0) + (int) ($invoiceTotals[$key] ?? 0),
            ];
        }

        return $series;
    }
}
