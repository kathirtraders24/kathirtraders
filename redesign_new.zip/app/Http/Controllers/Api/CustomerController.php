<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Customer::orderBy('name');

        if ($request->boolean('outstanding')) {
            $query->where('outstanding_balance', '>', 0)
                ->orderByDesc('outstanding_balance');
        }

        return response()->json($query->get());
    }

    public function show(Customer $customer): JsonResponse
    {
        return response()->json($customer);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name'                => 'required|string|max:255',
            'gstin'               => 'nullable|string|max:15',
            'phone'               => 'required|string|max:15',
            'email'               => 'nullable|email|max:255',
            'address'             => 'required|string',
            'state_code'          => 'required|string|size:2',
            'credit_limit'        => 'required|integer|min:0',
            'outstanding_balance' => 'required|integer|min:0',
        ]);

        $customer = Customer::create($validated);

        return response()->json($customer, 201);
    }

    public function update(Request $request, Customer $customer): JsonResponse
    {
        $validated = $request->validate([
            'name'                => 'sometimes|string|max:255',
            'gstin'               => 'nullable|string|max:15',
            'phone'               => 'sometimes|string|max:15',
            'email'               => 'nullable|email|max:255',
            'address'             => 'sometimes|string',
            'state_code'          => 'sometimes|string|size:2',
            'credit_limit'        => 'sometimes|integer|min:0',
            'outstanding_balance' => 'sometimes|integer|min:0',
        ]);

        $customer->update($validated);

        return response()->json($customer);
    }

    public function destroy(Customer $customer): JsonResponse
    {
        $customer->delete();

        return response()->json(null, 204);
    }
}
