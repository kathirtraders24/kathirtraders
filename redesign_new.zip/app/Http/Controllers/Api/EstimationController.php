<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Estimation;
use App\Services\DocumentNumberService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EstimationController extends Controller
{
    public function __construct(private DocumentNumberService $documentNumbers)
    {
    }

    public function index(): JsonResponse
    {
        $estimations = Estimation::with('lines')
            ->orderByDesc('date')
            ->orderByDesc('created_at')
            ->get();

        return response()->json($estimations);
    }

    public function show(Estimation $estimation): JsonResponse
    {
        return response()->json($estimation->load('lines', 'customer'));
    }

    public function showByNumber(string $number): JsonResponse
    {
        $estimation = Estimation::with('lines', 'customer')
            ->where('estimation_number', $number)
            ->firstOrFail();

        return response()->json($estimation);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'date'                    => 'required|date',
            'valid_until'             => 'nullable|date|after_or_equal:date',
            'customer_id'             => 'nullable|uuid|exists:customers,id',
            'customer_name'           => 'required|string|max:255',
            'customer_address'        => 'nullable|string',
            'customer_phone'          => 'nullable|string|max:15',
            'customer_gstin'          => 'nullable|string|max:15',
            'lines'                   => 'required|array|min:1',
            'lines.*.product_id'      => 'required|uuid',
            'lines.*.product_name'    => 'required|string',
            'lines.*.hsn_code'        => 'nullable|string',
            'lines.*.quantity'        => 'required|integer|min:1',
            'lines.*.unit'            => 'nullable|string|max:20',
            'lines.*.unit_rate'       => 'required|integer|min:0',
            'lines.*.discount'        => 'required|integer|min:0',
            'lines.*.gst_rate'        => 'required|numeric|min:0',
            'lines.*.cgst'            => 'required|integer|min:0',
            'lines.*.sgst'            => 'required|integer|min:0',
            'lines.*.igst'            => 'required|integer|min:0',
            'lines.*.line_total'      => 'required|integer|min:0',
            'sub_total'               => 'required|integer|min:0',
            'total_cgst'              => 'required|integer|min:0',
            'total_sgst'              => 'required|integer|min:0',
            'total_igst'              => 'required|integer|min:0',
            'grand_total'             => 'required|integer|min:0',
            'overall_discount_type'   => 'nullable|in:flat,percent',
            'overall_discount_value'  => 'nullable|numeric|min:0',
            'overall_discount'        => 'nullable|integer|min:0',
            'notes'                   => 'nullable|string',
        ]);

        // Default validity to 15 days from the estimation date when not supplied.
        if (empty($validated['valid_until'])) {
            $validated['valid_until'] = date('Y-m-d', strtotime($validated['date'] . ' +15 days'));
        }

        // Laravel's ConvertEmptyStringsToNull turns '' into null; these columns
        // are NOT NULL, so keep them as empty strings when no value was given.
        $validated['customer_address'] = $validated['customer_address'] ?? '';
        $validated['customer_phone']   = $validated['customer_phone'] ?? '';

        $estimation = DB::transaction(function () use ($validated) {
            $estimationNumber = $this->documentNumbers->next('EST');

            $estimation = Estimation::create(array_merge(
                $validated,
                ['estimation_number' => $estimationNumber, 'status' => 'draft']
            ));

            foreach ($validated['lines'] as $line) {
                $line['hsn_code'] = $line['hsn_code'] ?? '';
                $line['unit'] = $line['unit'] ?? 'Nos';
                $estimation->lines()->create($line);
            }

            return $estimation;
        });

        return response()->json($estimation->load('lines'), 201);
    }

    public function update(Request $request, Estimation $estimation): JsonResponse
    {
        $validated = $request->validate([
            'date'             => 'sometimes|date',
            'valid_until'      => 'sometimes|date',
            'customer_id'      => 'nullable|uuid|exists:customers,id',
            'customer_name'    => 'sometimes|string|max:255',
            'customer_address' => 'sometimes|nullable|string',
            'customer_phone'   => 'sometimes|nullable|string|max:15',
            'customer_gstin'   => 'nullable|string|max:15',
            'sub_total'        => 'sometimes|integer|min:0',
            'total_cgst'       => 'sometimes|integer|min:0',
            'total_sgst'       => 'sometimes|integer|min:0',
            'total_igst'       => 'sometimes|integer|min:0',
            'grand_total'      => 'sometimes|integer|min:0',
            'overall_discount_type'  => 'nullable|in:flat,percent',
            'overall_discount_value' => 'nullable|numeric|min:0',
            'overall_discount'       => 'nullable|integer|min:0',
            'notes'            => 'nullable|string',
            'status'           => 'sometimes|in:draft,sent,accepted,rejected,expired',
            'lines'            => 'sometimes|array|min:1',
            'lines.*.product_id'   => 'required_with:lines|uuid',
            'lines.*.product_name' => 'required_with:lines|string',
            'lines.*.hsn_code'     => 'nullable|string',
            'lines.*.quantity'     => 'required_with:lines|integer|min:1',
            'lines.*.unit'         => 'nullable|string|max:20',
            'lines.*.unit_rate'    => 'required_with:lines|integer|min:0',
            'lines.*.discount'     => 'required_with:lines|integer|min:0',
            'lines.*.gst_rate'     => 'required_with:lines|numeric|min:0',
            'lines.*.cgst'         => 'required_with:lines|integer|min:0',
            'lines.*.sgst'         => 'required_with:lines|integer|min:0',
            'lines.*.igst'         => 'required_with:lines|integer|min:0',
            'lines.*.line_total'   => 'required_with:lines|integer|min:0',
        ]);

        // NOT NULL text columns: restore '' if the empty-string->null middleware nulled them.
        if (array_key_exists('customer_address', $validated)) {
            $validated['customer_address'] = $validated['customer_address'] ?? '';
        }
        if (array_key_exists('customer_phone', $validated)) {
            $validated['customer_phone'] = $validated['customer_phone'] ?? '';
        }

        DB::transaction(function () use ($estimation, $validated) {
            if (isset($validated['lines'])) {
                $estimation->lines()->delete();
                foreach ($validated['lines'] as $line) {
                    $line['hsn_code'] = $line['hsn_code'] ?? '';
                    $line['unit'] = $line['unit'] ?? 'Nos';
                    $estimation->lines()->create($line);
                }
                unset($validated['lines']);
            }

            $estimation->update($validated);
        });

        return response()->json($estimation->fresh()->load('lines'));
    }

    public function destroy(Estimation $estimation): JsonResponse
    {
        $estimation->delete();

        return response()->json(null, 204);
    }
}
