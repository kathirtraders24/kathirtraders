<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\SalesInvoice;
use App\Models\StockEntry;
use App\Services\DocumentNumberService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller
{
    public function __construct(private DocumentNumberService $documentNumbers)
    {
    }

    public function index(): JsonResponse
    {
        $invoices = SalesInvoice::with('lines')
            ->orderByDesc('date')
            ->orderByDesc('created_at')
            ->get();

        return response()->json($invoices);
    }

    public function show(SalesInvoice $invoice): JsonResponse
    {
        return response()->json($invoice->load('lines', 'customer'));
    }

    public function showByNumber(string $number): JsonResponse
    {
        $invoice = SalesInvoice::with('lines', 'customer')
            ->where('invoice_number', $number)
            ->firstOrFail();

        return response()->json($invoice);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'date'                  => 'required|date',
            'customer_id'           => 'nullable|uuid|exists:customers,id',
            'customer_phone'        => 'required|string|max:15',
            'customer_name'         => 'required|string|max:255',
            'lines'                 => 'required|array|min:1',
            'lines.*.product_id'    => 'required|uuid',
            'lines.*.product_name'  => 'required|string',
            'lines.*.hsn_code'      => 'nullable|string',
            'lines.*.quantity'      => 'required|integer|min:1',
            'lines.*.unit'          => 'nullable|string|max:20',
            'lines.*.unit_rate'     => 'required|integer|min:0',
            'lines.*.discount'      => 'required|integer|min:0',
            'lines.*.gst_rate'      => 'required|numeric|min:0',
            'lines.*.cgst'          => 'required|integer|min:0',
            'lines.*.sgst'          => 'required|integer|min:0',
            'lines.*.igst'          => 'required|integer|min:0',
            'lines.*.line_total'    => 'required|integer|min:0',
            'sub_total'             => 'required|integer|min:0',
            'total_cgst'            => 'required|integer|min:0',
            'total_sgst'            => 'required|integer|min:0',
            'total_igst'            => 'required|integer|min:0',
            'grand_total'           => 'required|integer|min:0',
            'payment_mode'          => 'required|in:cash,upi,cheque,neft,credit',
        ]);

        // Customers are identified by phone in the UI; resolve to a UUID here.
        $customerId = $validated['customer_id']
            ?? $this->resolveCustomerId($validated['customer_phone'], $validated['customer_name']);

        $invoice = DB::transaction(function () use ($validated, $customerId) {
            $invoiceNumber = $this->documentNumbers->next('INV');

            $invoice = SalesInvoice::create([
                'invoice_number' => $invoiceNumber,
                'date'           => $validated['date'],
                'customer_id'    => $customerId,
                'customer_name'  => $validated['customer_name'],
                'sub_total'      => $validated['sub_total'],
                'total_cgst'     => $validated['total_cgst'],
                'total_sgst'     => $validated['total_sgst'],
                'total_igst'     => $validated['total_igst'],
                'grand_total'    => $validated['grand_total'],
                'payment_mode'   => $validated['payment_mode'],
                'status'         => 'draft',
            ]);

            foreach ($validated['lines'] as $line) {
                $line['hsn_code'] = $line['hsn_code'] ?? '';
                $line['unit'] = $line['unit'] ?? 'Nos';
                $invoice->lines()->create($line);
            }

            return $invoice;
        });

        return response()->json($invoice->load('lines'), 201);
    }

    public function update(Request $request, SalesInvoice $invoice): JsonResponse
    {
        if ($invoice->status !== 'draft') {
            return response()->json(['message' => 'Only draft invoices can be edited'], 422);
        }

        $validated = $request->validate([
            'date'                  => 'sometimes|date',
            'customer_id'           => 'nullable|uuid|exists:customers,id',
            'customer_phone'        => 'sometimes|string|max:15',
            'customer_name'         => 'sometimes|string|max:255',
            'sub_total'             => 'sometimes|integer|min:0',
            'total_cgst'            => 'sometimes|integer|min:0',
            'total_sgst'            => 'sometimes|integer|min:0',
            'total_igst'            => 'sometimes|integer|min:0',
            'grand_total'           => 'sometimes|integer|min:0',
            'payment_mode'          => 'sometimes|in:cash,upi,cheque,neft,credit',
            'lines'                 => 'sometimes|array|min:1',
            'lines.*.product_id'    => 'required_with:lines|uuid',
            'lines.*.product_name'  => 'required_with:lines|string',
            'lines.*.hsn_code'      => 'nullable|string',
            'lines.*.quantity'      => 'required_with:lines|integer|min:1',
            'lines.*.unit'          => 'nullable|string|max:20',
            'lines.*.unit_rate'     => 'required_with:lines|integer|min:0',
            'lines.*.discount'      => 'required_with:lines|integer|min:0',
            'lines.*.gst_rate'      => 'required_with:lines|numeric|min:0',
            'lines.*.cgst'          => 'required_with:lines|integer|min:0',
            'lines.*.sgst'          => 'required_with:lines|integer|min:0',
            'lines.*.igst'          => 'required_with:lines|integer|min:0',
            'lines.*.line_total'    => 'required_with:lines|integer|min:0',
        ]);

        // Resolve the phone identifier to a customer UUID when no id is given.
        if (empty($validated['customer_id']) && !empty($validated['customer_phone'])) {
            $validated['customer_id'] = $this->resolveCustomerId(
                $validated['customer_phone'],
                $validated['customer_name'] ?? $invoice->customer_name
            );
        }
        unset($validated['customer_phone']);

        DB::transaction(function () use ($invoice, $validated) {
            if (isset($validated['lines'])) {
                $invoice->lines()->delete();
                foreach ($validated['lines'] as $line) {
                    $line['hsn_code'] = $line['hsn_code'] ?? '';
                    $line['unit'] = $line['unit'] ?? 'Nos';
                    $invoice->lines()->create($line);
                }
                unset($validated['lines']);
            }

            $invoice->update($validated);
        });

        return response()->json($invoice->fresh()->load('lines'));
    }

    public function confirm(SalesInvoice $invoice): JsonResponse
    {
        if ($invoice->status !== 'draft') {
            return response()->json(['message' => 'Only draft invoices can be confirmed'], 422);
        }

        DB::transaction(function () use ($invoice) {
            // Deduct stock for each line item
            foreach ($invoice->lines as $line) {
                $stock = StockEntry::where('product_id', $line->product_id)->first();
                if ($stock) {
                    $newQty = $stock->quantity_on_hand - $line->quantity;
                    if ($newQty < 0) {
                        throw new \Exception("Insufficient stock for product: {$line->product_name}");
                    }
                    $stock->update(['quantity_on_hand' => $newQty]);
                }
            }

            $invoice->update(['status' => 'confirmed']);
        });

        return response()->json($invoice->fresh()->load('lines'));
    }

    public function cancel(SalesInvoice $invoice): JsonResponse
    {
        if ($invoice->status === 'cancelled') {
            return response()->json(['message' => 'Invoice is already cancelled'], 422);
        }

        DB::transaction(function () use ($invoice) {
            // If it was confirmed, restore stock
            if ($invoice->status === 'confirmed') {
                foreach ($invoice->lines as $line) {
                    $stock = StockEntry::where('product_id', $line->product_id)->first();
                    if ($stock) {
                        $stock->increment('quantity_on_hand', $line->quantity);
                    }
                }
            }

            $invoice->update(['status' => 'cancelled']);
        });

        return response()->json($invoice->fresh()->load('lines'));
    }

    /** Find a customer by phone, creating a minimal record if none exists. */
    private function resolveCustomerId(string $phone, string $name): string
    {
        $customer = Customer::firstOrCreate(
            ['phone' => $phone],
            [
                'name'                => $name,
                'address'             => '',
                'state_code'          => '33',
                'credit_limit'        => 0,
                'outstanding_balance' => 0,
            ]
        );

        return $customer->id;
    }
}
