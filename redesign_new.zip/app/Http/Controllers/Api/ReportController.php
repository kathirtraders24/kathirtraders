<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\InvoiceLineItem;
use App\Models\Order;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\SalesInvoice;
use App\Models\Supplier;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    /** Resolve [from, to] date range from the request, defaulting to the current month. */
    private function range(Request $request): array
    {
        $from = $request->query('from', now()->startOfMonth()->toDateString());
        $to   = $request->query('to', now()->toDateString());

        return [$from, $to];
    }

    public function sales(Request $request): JsonResponse
    {
        [$from, $to] = $this->range($request);

        $orders = Order::whereBetween('date', [$from, $to])
            ->selectRaw('DATE(date) as day, COUNT(*) as count, SUM(grand_total) as total')
            ->groupBy('day')->get()->keyBy('day');

        $invoices = SalesInvoice::where('status', 'confirmed')
            ->whereBetween('date', [$from, $to])
            ->selectRaw('DATE(date) as day, COUNT(*) as count, SUM(grand_total) as total')
            ->groupBy('day')->get()->keyBy('day');

        $days = collect($orders->keys())->merge($invoices->keys())->unique()->sort()->values();

        $rows = $days->map(fn ($d) => [
            'date'          => $d,
            'pos_bills'     => (int) ($orders[$d]->count ?? 0),
            'tax_invoices'  => (int) ($invoices[$d]->count ?? 0),
            'pos_total'     => (int) ($orders[$d]->total ?? 0),
            'invoice_total' => (int) ($invoices[$d]->total ?? 0),
            'total'         => (int) ($orders[$d]->total ?? 0) + (int) ($invoices[$d]->total ?? 0),
        ]);

        return response()->json([
            'from'         => $from,
            'to'           => $to,
            'rows'         => $rows,
            'grand_total'  => (int) $rows->sum('total'),
            'transactions' => (int) $rows->sum(fn ($r) => $r['pos_bills'] + $r['tax_invoices']),
        ]);
    }

    public function purchases(Request $request): JsonResponse
    {
        [$from, $to] = $this->range($request);

        $rows = PurchaseOrder::whereBetween('date', [$from, $to])
            ->orderBy('date')
            ->get(['po_number', 'date', 'supplier_name', 'total_amount', 'status'])
            ->map(fn ($po) => [
                'po_number'     => $po->po_number,
                'date'          => (string) $po->date->toDateString(),
                'supplier_name' => $po->supplier_name,
                'total_amount'  => (int) $po->total_amount,
                'status'        => $po->status,
            ]);

        return response()->json([
            'from'        => $from,
            'to'          => $to,
            'rows'        => $rows,
            'grand_total' => (int) $rows->sum('total_amount'),
        ]);
    }

    public function stock(): JsonResponse
    {
        $rows = Product::with('stock')->orderBy('name')->get()->map(function ($p) {
            $qty     = (int) ($p->stock?->quantity_on_hand ?? 0);
            $reorder = (int) ($p->stock?->reorder_level ?? 0);
            return [
                'sku'           => $p->sku,
                'name'          => $p->name,
                'category'      => $p->category,
                'unit'          => $p->unit,
                'quantity'      => $qty,
                'reorder_level' => $reorder,
                'unit_price'    => (int) $p->unit_price,
                'value'         => $qty * (int) $p->unit_price,
                'low'           => $qty <= $reorder,
            ];
        });

        return response()->json([
            'rows'            => $rows,
            'total_value'     => (int) $rows->sum('value'),
            'low_stock_count' => (int) $rows->where('low', true)->count(),
        ]);
    }

    public function gst(Request $request): JsonResponse
    {
        [$from, $to] = $this->range($request);

        $rows = InvoiceLineItem::whereHas('invoice', function ($q) use ($from, $to) {
                $q->where('status', 'confirmed')->whereBetween('date', [$from, $to]);
            })
            ->selectRaw('gst_rate, SUM(line_total) as taxable, SUM(cgst) as cgst, SUM(sgst) as sgst, SUM(igst) as igst')
            ->groupBy('gst_rate')
            ->orderBy('gst_rate')
            ->get()
            ->map(fn ($r) => [
                'gst_rate' => (float) $r->gst_rate,
                'taxable'  => (int) $r->taxable,
                'cgst'     => (int) $r->cgst,
                'sgst'     => (int) $r->sgst,
                'igst'     => (int) $r->igst,
                'total_tax' => (int) $r->cgst + (int) $r->sgst + (int) $r->igst,
            ]);

        return response()->json([
            'from'      => $from,
            'to'        => $to,
            'rows'      => $rows,
            'total_tax' => (int) $rows->sum('total_tax'),
        ]);
    }

    public function customerLedger(): JsonResponse
    {
        $rows = Customer::orderByDesc('outstanding_balance')
            ->get(['name', 'phone', 'credit_limit', 'outstanding_balance'])
            ->map(fn ($c) => [
                'name'                => $c->name,
                'phone'               => $c->phone,
                'credit_limit'        => (int) $c->credit_limit,
                'outstanding_balance' => (int) $c->outstanding_balance,
            ]);

        return response()->json([
            'rows'              => $rows,
            'total_outstanding' => (int) $rows->sum('outstanding_balance'),
        ]);
    }

    public function supplierLedger(): JsonResponse
    {
        $payables = PurchaseOrder::whereIn('status', ['ordered', 'received'])
            ->selectRaw('supplier_id, SUM(total_amount) as total')
            ->groupBy('supplier_id')
            ->pluck('total', 'supplier_id');

        $rows = Supplier::orderBy('name')->get(['id', 'name', 'phone', 'payment_terms'])
            ->map(fn ($s) => [
                'name'          => $s->name,
                'phone'         => $s->phone,
                'payment_terms' => $s->payment_terms,
                'payable'       => (int) ($payables[$s->id] ?? 0),
            ]);

        return response()->json([
            'rows'          => $rows,
            'total_payable' => (int) $rows->sum('payable'),
        ]);
    }
}
