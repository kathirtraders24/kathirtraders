<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Product::with('stock');

        if ($search = $request->query('q')) {
            $query->search($search);
        }

        return response()->json($query->orderBy('name')->get());
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json($product->load('stock'));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'sku'          => 'required|string|max:100|unique:products,sku',
            'name'         => 'required|string|max:255',
            'category'     => 'required|in:plumbing,electrical',
            'sub_category' => 'required|string|max:100',
            'unit'         => 'required|string|max:50',
            'hsn_code'     => 'required|string|max:20',
            'gst_rate'     => 'required|numeric|min:0|max:100',
            'unit_price'   => 'required|integer|min:0',
            'description'  => 'nullable|string',
        ]);

        $product = Product::create($validated);

        // Auto-create a stock entry with zero stock
        $product->stock()->create([
            'warehouse_location' => 'Main Warehouse',
            'quantity_on_hand'   => 0,
            'reorder_level'      => 10,
        ]);

        return response()->json($product->load('stock'), 201);
    }

    /**
     * Bulk-insert products from an imported spreadsheet.
     * Each row is validated independently: valid rows are inserted (with a stock
     * entry), duplicate SKUs are skipped, and invalid rows are reported — so one
     * bad row never aborts the whole import.
     */
    public function bulkStore(Request $request): JsonResponse
    {
        $data = $request->validate([
            'products'   => 'required|array|min:1|max:2000',
            'products.*' => 'array',
        ]);

        $created = 0;
        $skipped = [];
        $errors  = [];

        // SKUs already present, plus SKUs seen earlier in this same file.
        $seenSkus = [];

        foreach ($data['products'] as $index => $row) {
            $rowNum = $index + 1;

            $validator = Validator::make($row, [
                'sku'              => 'required|string|max:100',
                'name'             => 'required|string|max:255',
                'category'         => 'required|in:plumbing,electrical',
                'sub_category'     => 'required|string|max:100',
                'unit'             => 'required|string|max:50',
                'hsn_code'         => 'required|string|max:20',
                'gst_rate'         => 'required|numeric|min:0|max:100',
                'unit_price'       => 'required|integer|min:0',
                'description'      => 'nullable|string',
                'quantity_on_hand' => 'nullable|integer|min:0',
                'reorder_level'    => 'nullable|integer|min:0',
            ]);

            if ($validator->fails()) {
                $errors[] = [
                    'row'      => $rowNum,
                    'sku'      => $row['sku'] ?? '',
                    'messages' => $validator->errors()->all(),
                ];
                continue;
            }

            $valid = $validator->validated();
            $sku   = $valid['sku'];

            if (isset($seenSkus[$sku]) || Product::where('sku', $sku)->exists()) {
                $skipped[] = ['row' => $rowNum, 'sku' => $sku, 'reason' => 'Duplicate SKU'];
                continue;
            }
            $seenSkus[$sku] = true;

            DB::transaction(function () use ($valid) {
                $product = Product::create([
                    'sku'          => $valid['sku'],
                    'name'         => $valid['name'],
                    'category'     => $valid['category'],
                    'sub_category' => $valid['sub_category'],
                    'unit'         => $valid['unit'],
                    'hsn_code'     => $valid['hsn_code'],
                    'gst_rate'     => $valid['gst_rate'],
                    'unit_price'   => $valid['unit_price'],
                    'description'  => $valid['description'] ?? null,
                ]);

                $product->stock()->create([
                    'warehouse_location' => 'Main Warehouse',
                    'quantity_on_hand'   => $valid['quantity_on_hand'] ?? 0,
                    'reorder_level'      => $valid['reorder_level'] ?? 10,
                ]);
            });

            $created++;
        }

        return response()->json([
            'created' => $created,
            'skipped' => $skipped,
            'errors'  => $errors,
        ], 201);
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'sku'          => 'sometimes|string|max:100|unique:products,sku,'.$product->id,
            'name'         => 'sometimes|string|max:255',
            'category'     => 'sometimes|in:plumbing,electrical',
            'sub_category' => 'sometimes|string|max:100',
            'unit'         => 'sometimes|string|max:50',
            'hsn_code'     => 'sometimes|string|max:20',
            'gst_rate'     => 'sometimes|numeric|min:0|max:100',
            'unit_price'   => 'sometimes|integer|min:0',
            'description'  => 'nullable|string',
        ]);

        $product->update($validated);

        return response()->json($product->load('stock'));
    }

    public function destroy(Product $product): JsonResponse
    {
        $product->delete();

        return response()->json(null, 204);
    }
}
